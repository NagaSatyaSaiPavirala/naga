package com.mongo.app.controller;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class CreateControllerTest {
    @InjectMocks
    private CreateController createController;
    @Mock
    private PatientRepository patientRepository;

    @Test
    public void saveCustomerTest() {
        Patient mockPatient = mock(Patient.class);
        Patient expectedPatient = new Patient("pat1", "1", "Appollo","Fever");
        when(patientRepository.save(any(Patient.class))).thenReturn(expectedPatient);
        Patient result = createController.savePatient(mockPatient);
        Assert.assertEquals(result.getId(), expectedPatient.getId());
        Assert.assertEquals(result.getHospital(), expectedPatient.getHospital());
        Assert.assertEquals(result.getDisease(), expectedPatient.getDisease());

    }

    @Test
    public void readPatientTest() {
        List<Patient> patients = new ArrayList();
        Patient expectedPatient = new Patient("pat1", "1", "Appollo","Fever");
        patients.add(expectedPatient);
        when(patientRepository.findAll()).thenReturn(patients);
        List<Patient> result = createController.readPatient();
        Assert.assertEquals(result.get(0).getId(), expectedPatient.getId());
        Assert.assertEquals(result.get(0).getHospital(), expectedPatient.getHospital());
        Assert.assertEquals(result.get(0).getDisease(), expectedPatient.getDisease());

    }

    @Test
    public void modifyByIDTest() {
        Patient expectedPatient = new Patient("pat1", "1", "Appollo","Fever");
        when(patientRepository.findByName(anyString())).thenReturn(expectedPatient);
        createController.modifyByID("1","patname");
        verify(patientRepository, times(1)).save(expectedPatient);
    }

    @Test
    public void deleteByIDTTest() {
        String patientname= "patname";
        createController.deleteByID(patientname);
        verify(patientRepository, times(1)).deleteByname(patientname);
    }
}
