package com.mongo.app.controller;

public class Patient {
	String name;
	String id;
	String hospital;
	String disease;

	public Patient(String name, String id, String hospital, String disease) {
		this.name = name;
		this.id = id;
		this.hospital = hospital;
		this.disease = disease;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getHospital() {
		return hospital;
	}

	public void setHospital(String hospital) {
		this.hospital = hospital;
	}

	public String getDisease() {
		return disease;
	}

	public void setDisease(String disease) {
		this.disease = disease;
	}
}
