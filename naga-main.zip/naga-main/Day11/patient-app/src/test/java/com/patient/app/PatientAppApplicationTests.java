package com.patient.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;

import static org.junit.Assert.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest({PatientController.class})
@ActiveProfiles(value = "test")
/*
@SpringBootTest
class PatientAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/


@SpringBootTest
public class PatientAppApplicationTests {
	@Autowired
	private MockMvc mockMvc;
	@Value("${patient.get.url}")
	String geturl;

	@Value("${patient.get.all.url}")
	String getallurl;

	@Value("${patient.post.url}")
	String posturl;

	@Value("${patient.put.url}")
	String puturl;

	@Value("${patient.delete.url}")
	String deleteurl;

	@Test
	public void testPatientGet() throws Exception {
		ResultActions responseEntity  = mockMvc.perform(get(geturl).param("name","1"));
		responseEntity.andExpect(status().isOk());
		String result = responseEntity.andReturn().getResponse().getContentAsString();
		assertEquals("", result);
	}

	@Test
	public void testPatientWithValueGet() throws Exception {
		Patient patient=new Patient("pat1",1,"fever","Appollo");
		mockMvc.perform(post(posturl).contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(patient)).accept(MediaType.APPLICATION_JSON));

		ResultActions responseEntity  = mockMvc.perform(get(geturl).param("name","1"));
		responseEntity.andExpect(status().isOk());
		String result = responseEntity.andReturn().getResponse().getContentAsString();
		assertNotNull(result);
	}
	@Test
	public void testAllPatientGet() throws Exception {
		ResultActions responseEntity  = mockMvc.perform(get(getallurl));
		responseEntity.andExpect(status().isOk());
		String result = responseEntity.andReturn().getResponse().getContentAsString();
		assertNotNull(result);
	}


	@Test
	public void testSavePatientPost() throws Exception {
		Patient student=new Patient("pat1",1,"fever","Appollo");
		ResultActions responseEntity  = mockMvc.perform(post(posturl).contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(patient)).accept(MediaType.APPLICATION_JSON));
		responseEntity.andExpect(status().isOk());

	}

	@Test
	public void testUpdatePatientPut() throws Exception {
		Patient student=new Patient("pat1",1,"fever","Appollo");
		mockMvc.perform(post(posturl).contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(student)).accept(MediaType.APPLICATION_JSON));

		ResultActions responseEntity  = mockMvc.perform(put(puturl).param("name","pat1")
				.param("id","3"));
		responseEntity.andExpect(status().isOk());
		String result = responseEntity.andReturn().getResponse().getContentAsString();
		assertNotNull(result);

	}
	private ResultActions processApiRequest(String api, HttpMethod methodType, String name, Student student) {
		ResultActions response = null;
		try {
			switch (methodType) {
				case GET:
					response = mockMvc.perform(get(api).param("name",name));
					break;
				case POST:
					response = mockMvc.perform(post(api).contentType(MediaType.APPLICATION_JSON)
							.content(asJsonString(patient)).accept(MediaType.APPLICATION_JSON));
					break;
				case PUT:
					response = mockMvc.perform(put(api, name).contentType(MediaType.APPLICATION_JSON)
							.content(asJsonString(patient)).param("name",name).accept(MediaType.APPLICATION_JSON));
					break;
				case DELETE:
					response = mockMvc.perform(delete(api, name).param("name",name));
					break;
				default:
					fail("Method Not supported");
					break;
			}
		} catch (Exception e) {
			e.printStackTrace();
			fail();
		}
		return response;
	}

	private String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			final String jsonContent = mapper.writeValueAsString(obj);
			return jsonContent;
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private static Patient createEmployee(String name, int id, String cause,String hospital) {
		Patient patient = new Patient(name,id, cause,hospital);
		return patient;
	}

}
