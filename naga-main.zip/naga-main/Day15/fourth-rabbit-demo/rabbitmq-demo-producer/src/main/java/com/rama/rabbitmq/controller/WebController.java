package com.rama.rabbitmq.controller;

import com.rama.rabbitmq.model.Patient;
import com.rama.rabbitmq.service.RabbitMQSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/rabbitmq/")
public class WebController {
  @Autowired
  RabbitMQSender rabbitMQSender;

  @GetMapping(value = "/producer")
  public String producer(@RequestParam("name") String name, @RequestParam("id") String id) {

    Patient pat=new Patient();
    pat.setId(id);
    pat.setName(name);
    rabbitMQSender.send(pat);

    return "Message sent to the RabbitMQ  Successfully";
  }

  @PostMapping(value = "/patient")
  public String postEmployee(@RequestBody Patient patient) {

    rabbitMQSender.send(patient);

    return "Message sent to the RabbitMQ  Successfully";
  }
}
