package com.rama.artemis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArtemisDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
