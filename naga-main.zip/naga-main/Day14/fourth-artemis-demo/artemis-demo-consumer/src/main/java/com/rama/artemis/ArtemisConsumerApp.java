package com.rama.artemis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtemisConsumerApp {

	public static void main(String[] args) {
		SpringApplication.run(ArtemisConsumerApp.class, args);
	}

}
