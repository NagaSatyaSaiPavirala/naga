package com.rama.artemis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtemisProducerApp {

	public static void main(String[] args) {
		SpringApplication.run(ArtemisProducerApp.class, args);
	}

}
