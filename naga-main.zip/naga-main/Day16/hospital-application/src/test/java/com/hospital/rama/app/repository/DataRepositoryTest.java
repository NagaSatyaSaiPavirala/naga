package com.hospital.rama.app.repository;

public class DataRepositoryTest {
}
